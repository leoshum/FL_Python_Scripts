#pip install -r requirements.txt
#%%s

from datetime import datetime
import json
import requests
from packaging import version
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

def getJson(url: str):
    headers = { "Accept" : "application/json" }
    response = get(url, headers = headers)
    return json.loads(response)

def get(url: str, headers = {}):
    headers.update({"Authorization" : f"Bearer {token}"})

    response = requests.get(
        url = url,
        verify = False,
        headers = headers)

    return response.text


configuration_file_name = "configuration.json"

with open(configuration_file_name) as configuration_file:
    configuration = json.loads(configuration_file.read())

token = configuration['token']
ticket_match = "https://frontlinetechnologies.atlassian.net/browse/CW0575-"
ticket_number_length = 6

from_version = version.parse(configuration['version']['first'])
to_version = version.parse(configuration['version']['last'])

baseurl = f"https://{configuration['host']}/app/rest"

comment_file_name = f"{from_version.__str__()}-{to_version.__str__()}.xlsx"

if configuration['branch'] == 'prod' or configuration['branch'] == 'production' or configuration['branch'] == 'main':
    configuration['branch'] = 'Production'
    job_id = 'BuildNewArchitecture_Main_BuildVersion'
elif configuration['branch'] == 'release':
    configuration['branch'] = 'Release'
    job_id = 'BuildNewArchitecture_TagFix_BuildVersion'
elif configuration['branch'] == 'develop' or configuration['branch'] == 'dev':
    configuration['branch'] = 'Develop'
    job_id = 'BuildNewArchitecture_Trunk_BuildVersion'        

book = Workbook()
sheet = book.active
sheet.title = "Comments"


builds = []
current_version = from_version
start = 0
while current_version >= from_version:
    url = f"{baseurl}/builds?locator=defaultFilter:false,start:{start},buildType:{job_id}"
    response = getJson(url)

    for build in response['build']:
        current_version = version.parse(build['number'])
        if current_version >= from_version and current_version <= to_version:
            builds.append({
                'id' : build['id'],
                'version' : build['number']})
    start += 100

sheet.append([configuration['branch']])
sheet.append(["Version","Author","Date","Jira Ticket","Comment"])
width = {
    'version' : 0,
    'author' : 0,
    'date' : 0,
    'ticket' : 0,
    'comment' : 0
}

#Add date from build

for build in builds:
    url = f"{baseurl}/changes?locator=build:(id:{build['id']})&fields=change(username,date,comment)"
    response = getJson(url)
    for change in response['change']:
        change['comment'] = change['comment'].replace('\n', '')
        if ticket_match in change['comment']:
            ticket = change['comment'][change['comment'].index(ticket_match):len(ticket_match)+ticket_number_length]
            comment = change['comment'][len(ticket_match)+ticket_number_length:]
        else:
            ticket = ''
            comment = change['comment']
        date = str(datetime.strptime(change['date'][0:8], '%Y%m%d').date())
        sheet.append([build['version'], change['username'],date,ticket,comment])
        length_version =len(build['version'])
        length_username =len(change['username'])
        length_ticket =len(ticket)
        length_comment =len(comment)
        length_date =len(date)
        if length_version > width['version']:
            width['version'] = length_version
        if length_username > width['author']:
            width['author'] = length_username
        if length_ticket > width['ticket']:
            width['ticket'] = length_ticket
        if length_comment > width['comment']:
            width['comment'] = length_comment
        if length_date > width['date']:
            width['date'] = length_date

for i, column_width in enumerate(width.values(),1):  # ,1 to start at 1
    sheet.column_dimensions[get_column_letter(i)].width = column_width + 3

book.save(filename=comment_file_name)